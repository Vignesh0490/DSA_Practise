package BmiTest;
//Regular Test method @Test
//Parameterized test -- @ParameterizedTest

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import BMI.BmiCalculator;

public class BmiTesting {
	
	@ParameterizedTest()
	//@ValueSource(double = {70.0,89.0,78.0,110.0})
	//CsvSource(value = "70.0,1.72","95.0,1.72","78.0,1.72")
	public void DietRecommended(double weight, double height) {
		weight = 90;
		height = 1.72;
		boolean recommended = BmiCalculator.isDietRecommended(weight,height);
		assertTrue(recommended);				
	}
	@Test(timeout= 1000)
	public void ThrowsArithmeticException_HeightZero() throws InterruptedException  {
		 double weight = 50.0;
		 double height = 0.00;
		  Executable executable = () -> BmiCalculator.isDietRecommended(weight,height);		
		  assertThrows(ArithmeticException.class,executable);
		 
	}
}
