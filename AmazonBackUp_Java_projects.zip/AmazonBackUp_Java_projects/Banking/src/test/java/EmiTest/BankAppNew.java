package EmiTest;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import emicalculator.BankingApplication;
import emicalculator.ComplexInterest;

public class BankAppNew {
	@Test
	public void testCalculateEMI() {
	BankingApplication bankingApp = new BankingApplication();
	double principal = 50000;
	double interestRate = 5;
	int tenure = 1; // 1year

	double expectedEMI = 4275.35;
	double actualEMI = bankingApp.calculateEMI(principal, interestRate, tenure);
	assertEquals(expectedEMI, actualEMI);
	}
	//@Test
	public void testCalculateCompoundInterest() {
	ComplexInterest com = new ComplexInterest();
	double principal = 50000;
	double interestRate = 5;
	int tenure = 1; // 1 year

	double expectedInterest = 1304.2;
	double actualInterest = com.calculateComplex(principal, interestRate, tenure);
	//double actualInterest = bankingApp.calculateCompoundInterest(principal, interestRate, tenure);
	assertEquals(expectedInterest, actualInterest);
	}
}
