package EmiTest;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import emicalculator.BankingApplication;
import emicalculator.ComplexInterest;

public class BankappTest {
	
	@Test
	public void testemi() {
	BankingApplication bp = new BankingApplication();

	assertTrue(bp.calculateEMI(100000, 5, 3) == 502325.5813953488);
	}


	@Test
	public void test2CompundInterest() {
	ComplexInterest ci = new ComplexInterest();

	assertTrue(ci.calculateComplex(100000, 5, 3) == 15762.500000000015);
	}

	}


