package EmiTest;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import emicalculator.BankingApplication;
import emicalculator.ComplexInterest;

public class BankingApplicationTesting {

	BankingApplication bank = new BankingApplication();
	ComplexInterest com = new ComplexInterest();

	@Test
	public void testCalculateEMI() {
		
		assertEquals(10083.333333333334, bank.calculateEMI(10000, 10, 2));
		/*
		 * float p = 10000; float r = 10; float t = 2;
		 */
		//float em = BankingApplication.calculateEMI(p, r, t);
		//assertEquals(461.44977, bank.calculateEMI(10000, 10, 2));
		
	}
	@Test
	public void testComplex() {
		//double p = 1000;
		//double r = 5;
		//double t = 3;
		//double comp = ComplexInterest.calculateComplex(p, r, t);
		assertEquals(15762.500000000015, com.calculateComplex(100000,5, 3));
		
	}
}