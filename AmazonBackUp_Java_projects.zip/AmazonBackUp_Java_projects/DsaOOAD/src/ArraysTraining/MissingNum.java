package ArraysTraining;
//https://takeuforward.org/arrays/find-the-missing-number-in-an-array/

public class MissingNum {
	public static int missingNumber(int a[], int N) {

		// summation of N natural numbers
		int sum = (N * (N + 1)) / 2;
		// adding all the array elements
		int s2 = 0;
		for (int i = 0; i < N - 1; i++) {
			s2 = s2 + a[i]; // need to calculation the total of the array
		}
		int missingNumber = sum - s2;
		return missingNumber;
	}

	public static void main(String[] args) {
		int N = 5;
		int ab[] = {1,2,4,5};
		int missingOne = missingNumber(ab, N);
		System.out.println("The missing number is: "+ missingOne);

	}

}
