package ArraysTraining;

import java.util.ArrayList;
import java.util.HashSet;

public class UnionArray {
	public static ArrayList<Integer> findUnion(int arr1[], int arr2[], int n, int m) {
		HashSet<Integer> s  = new HashSet<>();
		ArrayList<Integer> union = new ArrayList<>();
		for (int i = 0; i < n; i++)
			s.add(arr1[i]); // adding the values to set

		for (int i = 0; i < m; i++)
			s.add(arr2[i]); // adding the values to set

		for (int val : s)
			union.add(val); // adding the sorted set in arrayList

		return union;
	}

	public static void main(String[] args) {
		int n = 10, m = 7;
		int arr1[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
		int arr2[] = { 2, 3, 4, 4, 5, 11, 12 };
		ArrayList<Integer> union = findUnion(arr1, arr2, n, m);
		System.out.println("The union of two arrays are :");
		for (int ans : union) {			
			System.out.print(ans + " ");
		}

	}

}
