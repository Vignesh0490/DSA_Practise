package DSA;

import java.util.HashSet;

public class RemoveDuplicates {
	public static HashSet<Integer> removeDuplicates(int[] arr) {
		// using hash-set to store unique elements
		HashSet<Integer> uniqueSet = new HashSet<>();
		for (int num : arr) {
			uniqueSet.add(num);

		}
		return uniqueSet;

	}

	public static void main(String[] args) {
		int[] arr = { 1, 2, 3,3, 4, 5, 6, 7, 7, 8 };
		HashSet<Integer> unique = removeDuplicates(arr);
		System.out.println(unique);

	}

}
