package DSA;
//https://www.youtube.com/watch?v=nfM855bsnF0&ab_channel=QAFox
//To rotate the value with 3 elements

import java.util.Arrays;

public class RotateLeftArray {

	public static void main(String[] args) {
		int a[] = { 1, 2, 3, 4, 5 };
		int n = 3;
		for (int j = 1; j <=n; j++) { //outer for loop
			int size = a.length;
			int first = a[0];
			for (int i = 0; i < size - 1; i++) { //inner for loop

				a[i] = a[i + 1];
			}
			a[size - 1] = first;

		}

		System.out.println("Left Rotate: " + Arrays.toString(a));
	}

}
//Swapping
//temp = a[0];
 //a[0] = a[size-1];
//a[size-1] = temp;
