package DSA;

import java.util.Arrays;

//Rotating the array by right

public class RotateRightArray {

	public static void main(String[] args) {
		int a[] = { 1, 2, 3, 4, 5 };
		int size = a.length;
		int last = a[size - 1]; // as per indexing
		for (int i = size - 1; i > 0; i--) {
			a[i] = a[i - 1]; // values in array "a" is getting decremented

		}
		a[0] = last;
		System.out.println(Arrays.toString(a));
	}

}
