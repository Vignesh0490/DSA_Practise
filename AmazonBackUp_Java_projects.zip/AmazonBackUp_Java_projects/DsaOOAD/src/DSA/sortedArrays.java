package DSA;

import java.util.Arrays;

public class sortedArrays {
	public static int[] mergedArrays(int[] arr1, int[] arr2) {
		int len1 = arr1.length;
		int len2 = arr2.length;
		int merged[] = new int[len1 + len2];

		int i = 0; // pointer for arr1
		int j = 0; // pointer for arr2
		int k = 0; // pointer for merged

		// Traversing both the arrays
		while (i < len1 && j < len2) {
			if (arr1[i] < arr2[j]) {
				merged[k] = arr1[i];
				i++;
			} else {
				merged[k] = arr2[j];
				j++;
			}
			k++;
		}
		// To add remaining elements from arr1
		while (i < len1) {
			merged[k] = arr1[i];
			i++;
			k++;
		}
		// To add the remaining elements from arr2
		while (j < len2) {
			merged[k] = arr2[j];
			j++;
			k++;
		}
		return merged;

	}

	public static void main(String[] args) {
		int[] arr1 = {1, 3, 5, 7};
		int[] arr2 = {2, 4, 6, 8};
		int merged[] = mergedArrays(arr1,arr2);
		// converting into readable form string representation for easy output
		System.out.println("Merged Sorted Arrays: " + Arrays.toString(merged)); 

	}

}
