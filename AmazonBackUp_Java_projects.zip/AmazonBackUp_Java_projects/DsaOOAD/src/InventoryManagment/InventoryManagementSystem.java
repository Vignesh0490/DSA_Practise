package InventoryManagment;

import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;

public class InventoryManagementSystem {
	private Map<Product, Integer> inventory;
	private PriorityQueue<Product> restockPriorityQueue;

	public InventoryManagementSystem() {
		inventory = new HashMap<>();
		restockPriorityQueue = new PriorityQueue<>((p1,p2) -> p1.getStock() - p2.getStock());
//		Product p1 = new Product(null, 0);
//		p1.getStock();
//		Product p2 = new Product(null, 0);
//		p2.getClass();
	}

	public void addProduct(Product product) {
		inventory.put(product, product.getStock());
		restockPriorityQueue.add(product);
	}
	
	//if(inventory.containsKey(product)
	//    int currentStock = inventory.get(product);
	// if(quantity>= currentStock){
	//inventory.put(product, currentstock - quantity);

	public void sellProduct(Product product, int quantity) {
		if (inventory.containsKey(product)) {
			int currentStock = inventory.get(product);
			if (currentStock >= quantity) {
				inventory.put(product, currentStock - quantity);
				restockPriorityQueue.add(product);
				System.out.println("Sold " + quantity + " unit of " + product.getProduct());
			} else {
				System.out.println("Not enough stock for " + product.getProduct());
			}
		}
	}

	public void restockProduct(Product product, int quantity) {
		if (inventory.containsKey(product)) {
			int currentStock = inventory.get(product);
			inventory.put(product, currentStock + quantity);
			restockPriorityQueue.add(product);
			System.out.println("Restocked " + quantity + " units of " + product.getProduct());
		}
	}

	public void generateReport() {
		for (Product product : inventory.keySet()) {
			System.out.println("Product: " + product.getProduct());
			System.out.println("currentStocklevel: " + product.getStock());
		}
	}

	public void optimizeRestocking() {
		while (!restockPriorityQueue.isEmpty()) {
			Product product = restockPriorityQueue.poll();
		}
	}

}
