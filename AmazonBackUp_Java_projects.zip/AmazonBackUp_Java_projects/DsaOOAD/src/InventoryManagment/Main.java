package InventoryManagment;

public class Main {

	public static void main(String[] args) {
		InventoryManagementSystem inventorySystem = new InventoryManagementSystem();
		Product product1 = new Product("Product A", 50);
		Product product2 = new Product("Product B", 30);
		inventorySystem.addProduct(product1);
		inventorySystem.addProduct(product2);
		
		inventorySystem.sellProduct(product1, 20);
		inventorySystem.sellProduct(product2, 15);
		
		inventorySystem.restockProduct(product2, 10);
		inventorySystem.generateReport();
		
		inventorySystem.optimizeRestocking();

	}

}
