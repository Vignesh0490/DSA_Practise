package projectAmazon;

import com.opencsv.CSVReader;

import java.io.FileReader;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class BuyItem extends SearchItem {

	// @DataProvider(name = "shippingData")
	private String[] readCSV(String filePath) throws Exception {
		String[] data = null;
		try (CSVReader reader = new CSVReader(new FileReader(
				"C:\\Users\\mourov\\Downloads\\Atlas\\Capstone\\Project_Amazon\\Project_Amazon\\CSV\\Shipping_address.csv"))) {
			data = reader.readNext();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return data;
	}

	// @Test(dataProvider = "shippingdata")
	public void enterShippingAddress(WebDriver driver) throws Exception {
		this.driver = driver;

		String[] shippingData = readCSV("Shipping_address.csv");
		String name = shippingData[0];
		String mobileNumber = shippingData[1];
		String pincode = shippingData[2];
		String flat = shippingData[3];
		String area = shippingData[4];
		String landMark = shippingData[5];

		Thread.sleep(5000);
		WebElement fullName = driver.findElement(By.id("address-ui-widgets-enterAddressFullName"));
		fullName.sendKeys(name);
		WebElement mobileNum = driver.findElement(By.id("address-ui-widgets-enterAddressPhoneNumber"));
		mobileNum.sendKeys(mobileNumber);
		WebElement pin = driver.findElement(By.id("address-ui-widgets-enterAddressPostalCode"));
		pin.sendKeys(pincode);
		WebElement flatDetails = driver.findElement(By.id("address-ui-widgets-enterAddressLine1"));
		flatDetails.sendKeys(flat);
		WebElement areaDetails = driver.findElement(By.id("address-ui-widgets-enterAddressLine2"));
		areaDetails.sendKeys(area);
		WebElement landMarkDetails = driver.findElement(By.id("address-ui-widgets-landmark"));
		landMarkDetails.sendKeys(landMark);
		WebElement useThisAddress = driver
				.findElement(By.xpath("//input[@aria-labelledby='address-ui-widgets-form-submit-button-announce']"));
		useThisAddress.click();
	}

//public void enterBillingAddress() {
//	 WebElement billingAddressField = driver.findElement(By.id("billing-address"));
//	 billingAddressField.sendKeys("50/4, telephone colony, second Street, Adambakkam- 6000088");
//	 Assert.assertEquals(billingAddressField.getAttribute("value"), "50/4, telephone colony, second Street, Adambakkam- 6000088");
// }

	public void enterPaymentDetails(WebDriver driver) {
		this.driver = driver;
		WebElement useThisShipAddress = driver
				.findElement(By.xpath("//input[@aria-labelledby='shipToThisAddressButton-announce']"));
		useThisShipAddress.click();
		WebElement cashOnDelivery = driver.findElement(
				By.xpath("//span[@class='a-color-base a-text-bold' and text()='Cash on Delivery/Pay on Delivery']"));
		cashOnDelivery.click();
		WebElement useCashOnDeliveryMethod = driver
				.findElement(By.xpath("//input[@name='ppw-widgetEvent:SetPaymentPlanSelectContinueEvent']"));
		useCashOnDeliveryMethod.click();
	}

	public void buyTheOrder(WebDriver driver) throws Exception {
		this.driver = driver;
		Thread.sleep(10000);
		WebElement buyItem = driver
				.findElement(By.xpath("//input[@aria-labelledby='bottomSubmitOrderButtonId-announce']"));
		buyItem.click();
		String expectedMessage = "Order placed, thank you!";
		Assert.assertEquals("Order placed, thank you!", expectedMessage);
	}

}
