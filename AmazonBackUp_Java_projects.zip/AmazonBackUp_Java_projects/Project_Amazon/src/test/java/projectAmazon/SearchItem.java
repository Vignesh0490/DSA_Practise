package projectAmazon;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class SearchItem extends LoginPage {

	public void searchAndViewElectronics(WebDriver driver) throws Exception {

		this.driver = driver;
		String searchQuery = "LCD Writing Tablet";
		// select command is used to choose the appropriate category
		Select searchDropDown = new Select(driver.findElement(By.id("searchDropdownBox")));
		searchDropDown.selectByVisibleText("Electronics");

		WebElement searchBox = driver.findElement(By.id("twotabsearchtextbox"));
		searchBox.sendKeys(searchQuery);
		WebElement searchButton = driver.findElement(By.id("nav-search-submit-button"));
		searchButton.click();

		// To check product availability
		WebElement productAvailabilityElectronics = driver
				.findElement(By.xpath("//span[contains(text(),'Lapster LCD Writing Tablet 8.5 inches')]"));
		productAvailabilityElectronics.click();

		ArrayList<String> newWindow = new ArrayList<>(driver.getWindowHandles());
		driver.switchTo().window(newWindow.get(1));

		// Add to cart
		// Thread.sleep(2000);
		WebElement addToCartElectronics = driver.findElement(By.xpath("//input[@title='Add to Shopping Cart']"));
		addToCartElectronics.click();
		// Added to cart
		WebElement addedToCart = driver.findElement(By.xpath("//span[contains(text(),'Added to Cart')]"));
		Assert.assertTrue(addedToCart.isDisplayed());

		// proceed to checkout
		// WebElement proceedToCheckoutElectronics =
		// driver.findElement(By.xpath("//input[@value='Proceed to checkout']"));
		// proceedToCheckoutElectronics.click();

	}

	public void searchAndViewFashion(WebDriver driver) {
		this.driver = driver;
		String searchFashion = "baby toys";

		Select searchDropdownFashion = new Select(driver.findElement(By.id("searchDropdownBox")));
		searchDropdownFashion.selectByVisibleText("Baby");

		WebElement searchBoxFashion = driver.findElement(By.id("twotabsearchtextbox"));
		searchBoxFashion.sendKeys(searchFashion);
		WebElement searchButtonFashion = driver.findElement(By.id("nav-search-submit-button"));
		searchButtonFashion.click();

		// To check product availability
		WebElement productAvailabilityFashion = driver
				.findElement(By.xpath("//span[contains(text(),'Cable World® Colourful Plastic Non Toxic Set of 7')]"));
		productAvailabilityFashion.click();

		ArrayList<String> newWindow = new ArrayList<>(driver.getWindowHandles());
		driver.switchTo().window(newWindow.get(2));

		// Add to cart
		WebElement addToCartFashion = driver.findElement(By.xpath("//input[@title='Add to Shopping Cart']"));
		addToCartFashion.click();

		// Added to cart
		WebElement addedToCart = driver.findElement(By.xpath("//span[contains(text(),'Added to Cart')]"));
		Assert.assertTrue(addedToCart.isDisplayed());

		// proceed to checkout
		WebElement proceedToCheckoutFashion = driver.findElement(By.xpath("//input[@value='Proceed to checkout']"));
		proceedToCheckoutFashion.click();
	}

}
