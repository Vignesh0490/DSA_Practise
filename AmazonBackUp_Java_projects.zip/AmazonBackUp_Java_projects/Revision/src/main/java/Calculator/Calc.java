package Calculator;

public class Calc {
	public int add(int a, int b) {
		int c = a+b;
		return c;
	}
	public int sub(int a, int b) {
		int c = a-b;
		return c;
	}
	public int mul(int a, int b) {
		int c = a*b;
		return c;
	}

}
