package Test;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import Calculator.Calc;

public class TestCalculator {
	Calc calc = new Calc();

	@BeforeClass
	public static void set() {
		System.out.println("Calculation execution methods started");
	}

	@Before
	public void before() {
		System.out.println("Before Test");
	}

	@Test
	public void add() {
		assertEquals(5, calc.add(3, 2));
	}

	@Test
	public void sub() {
		assertEquals(1, calc.sub(3, 2));
	}

@Test
public void mul() {
	assertEquals(6,calc.mul(3, 2));
}

	@After
	public void after() {
		System.out.println("Tested");
	}

	@AfterClass
	public static void complete() {
		System.out.println("Calculation execution methods completed");
	}
}
