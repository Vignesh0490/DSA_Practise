package Banking;

//https://www.testingdocs.com/bank-account-junit-tests/
public class bankingService {
	public String name;
	public String acc_type;
	public String location;
	
	public bankingService(String name, String acc_type, String location) {
		this.name = name;
		this.acc_type = acc_type;
		this.location = location;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAcc_type() {
		return acc_type;
	}

	public void setAcc_type(String acc_type) {
		this.acc_type = acc_type;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
	

}
