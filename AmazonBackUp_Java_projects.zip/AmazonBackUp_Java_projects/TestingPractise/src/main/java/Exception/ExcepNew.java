package Exception;

import java.util.List;

public class ExcepNew {
	public int excep(int number) {
		if(number < 0) {
			throw new IllegalArgumentException ("Number is negative");	
		}
		else {
			System.out.println("Number is positive");
		}
		return number;
	}
}
