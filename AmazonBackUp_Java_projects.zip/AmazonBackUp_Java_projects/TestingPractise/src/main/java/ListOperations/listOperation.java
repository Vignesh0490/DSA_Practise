package ListOperations;

import java.util.List;

public class listOperation {
	public int sumOfNum(List<Integer> numbers) {
		int sum = 0;
		for (int number : numbers) {
			sum = sum + number;
		}
		return sum;
	}

	public int averageOf(List<Integer> numbers) {
		int sumnew = sumOfNum(numbers);
		return sumnew / numbers.size();
	}

	public int max(List<Integer> numbers) {
		int maxnew = numbers.get(0);
		for (int number : numbers) {
			if (number > maxnew) {
				maxnew = number;
			}
		}
		return maxnew;
	}
}
