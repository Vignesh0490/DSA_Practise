package Registration;

public class UserRegistration {

	public boolean validateUsername(String username) {
		return username.matches("^[a-zA-Z0-9]{5,20}$");
	}
	public boolean validateEmail(String email) {
		return email.matches("^[a-zA-Z0-9+_.-]+@(.+)$");
	}
	public boolean validatePassword(String password) {
		return password.length()>=8 && password.matches("^(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[!@#$%&*^_+=]).*$");
	}
	public boolean validateAge(int age) {
		return age>=13 && age<=100;
	}
}
