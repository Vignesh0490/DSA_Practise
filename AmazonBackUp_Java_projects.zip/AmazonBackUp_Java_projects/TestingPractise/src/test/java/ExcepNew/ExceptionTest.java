package ExcepNew;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;

import org.junit.Before;
import org.junit.Test;

import Exception.ExcepNew;

public class ExceptionTest {
	
	ExcepNew arg;
	
	@Before
	public void set() {
		arg = new ExcepNew();
	}
	@Test
	public void argument() {
	try {
		arg.excep(-5);
	fail("IllegalArgumentException");		
	}
	catch(IllegalArgumentException e) {
		assertEquals("Number is negative", e.getMessage());
		System.out.println(e.getMessage());
		
	}
	}
}
