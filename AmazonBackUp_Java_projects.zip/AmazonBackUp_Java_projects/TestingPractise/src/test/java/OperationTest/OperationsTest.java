package OperationTest;

import static org.testng.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import ListOperations.listOperation;

public class OperationsTest {

	static listOperation operate;

	@Before
	public void setUp() {
		operate = new listOperation();
	}

	@Test
	public void sumTest() {
		List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);
		assertEquals(15, operate.sumOfNum(numbers));
		System.out.println("SUM: " + operate.sumOfNum(numbers));
	}

	@Test
	public void avgTest() {
		List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);
		assertEquals(3, operate.averageOf(numbers));
		System.out.println("AVERAGE: " + operate.averageOf(numbers));
	}

	@Test
	public void max() {
		List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);
		assertEquals(5, operate.max(numbers));
		System.out.println("MAX:" + operate.max(numbers));
	}

	@After
	public void execute() {
		System.out.println("Executed successfully");
	}

}
