package TestCal;

import static org.testng.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


import Calculator.Calculator;

public class TestCal {

	Calculator calc = new Calculator();
	
	@BeforeClass
	public static void Start() {
		System.out.println("Start");		
	}
	@Before
	public void before() {
		System.out.println("Calculation Started");
	}
	@Test
	public void add() {
		assertEquals(5,calc.add(3, 2));
	}
	@Test
	public void sub() {
		assertEquals(2, calc.sub(5, 3));
	}
	@Test
	public void div() {
		assertEquals(10, calc.div(100, 10));
	}
	@After
	public void after() {
		System.out.println("Calculation Ended");		
	}
	@AfterClass
	public static void end() {
		System.out.println("End");
	}
}


