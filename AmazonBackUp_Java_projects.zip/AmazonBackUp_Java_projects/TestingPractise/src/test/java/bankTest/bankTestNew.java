package bankTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.testng.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import Banking.bankingService;

public class bankTestNew {
	 bankingService bank;

@Before
public void setUp(){
	bank = new bankingService(null, null, null);
	bank.setName("Vignesh");
	bank.setLocation("Pondicherry");
	bank.setAcc_type("current");
}
@Test
public void name() {
	assertEquals("Vignesh", bank.getName());
}
public void location() {
	assertEquals("Pondicherry",bank.getLocation());
}
public void account() {
	assertEquals("current", bank.getAcc_type());
}
@After
public void complete() {
 System.out.println("Account completed successfully");
}
}


