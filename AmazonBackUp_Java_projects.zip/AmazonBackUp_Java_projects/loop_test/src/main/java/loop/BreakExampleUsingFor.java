package loop;
import java.util.*;

public class BreakExampleUsingFor {
	public int findSumUntilZero(int[] array) {
		int sum = 0;
		for (int number : array) {
		if (number == 0) {
		break; //Breaks out of for loop
		}
		sum += number;
		}
		return sum;
		}
		}

