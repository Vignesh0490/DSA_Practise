package loop;

public class ContinueExampleUsingFor {
	public int findSumExcludingNegatives(int[] array) {
		int sum = 0;
		for (int number : array) {
		if (number < 0) {
		continue; //goes to end of loop and continues
		}
		sum += number;
		}
		return sum;
		}
		}

