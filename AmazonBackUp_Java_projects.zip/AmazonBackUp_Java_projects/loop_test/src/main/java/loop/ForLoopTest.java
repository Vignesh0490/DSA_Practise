package loop;

public class ForLoopTest {
	public int findSumOfArray(int[] array) {
		/*
		* There are better ways to loop around an array. We will look at
		* them as we go on. Using this example as simple illustration of a
		* do while loop.
		*/
		int sum = 0;
		int lengthOfArray = array.length;
		for (int counter = 0; // initialization and declaration
		counter < lengthOfArray; // condition check
		counter++) { // increment
		sum += array[counter];// same as sum = sum + array[counter]
		}
		return sum;
		}
		}

