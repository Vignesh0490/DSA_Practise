package loop_test;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import loop.BreakExampleUsingFor;

public class BreakExample {
	@Test
	public void testBreakExampleUsingFor() {
	BreakExampleUsingFor example = new BreakExampleUsingFor();

	/* Ideally should be in separate java test methods */
	assertEquals(1 + 5 + 3, example.findSumUntilZero(new int[] { 1, 5, 3, 0, 8, 7 }));

	assertEquals(1 + 5 + 3 + 8 + 7, example.findSumUntilZero(new int[] { 1, 5, 3, 8, 0 }));
	}

}
