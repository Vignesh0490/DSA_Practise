package loop_test;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import loop.ContinueExampleUsingFor;

public class ContiExampleUsingFor {

@Test
public void testContinueExampleUsingFor() {
ContinueExampleUsingFor example = new ContinueExampleUsingFor();

assertEquals(5 + 8 + 7, example
.findSumExcludingNegatives(new int[] { -1, 5, -3, 0,
8, 7 }));

}
}

