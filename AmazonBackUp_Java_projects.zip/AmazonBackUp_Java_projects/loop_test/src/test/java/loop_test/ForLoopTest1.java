package loop_test;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import loop.ForLoopTest;

public class ForLoopTest1 {
	@Test
	public void sumArrayUsingForLoop() {
	ForLoopTest example = new ForLoopTest();

	/* Ideally should be in separate java test methods */
	assertEquals(25, example.findSumOfArray(new int[] {
	6, 8, 12 }));
	assertEquals(0, example.findSumOfArray(new int[] {
	0, -1, 1 }));
	assertEquals(-15, example.findSumOfArray(new int[] {
	0, -1, -14 }));
	assertEquals(0, example
	.findSumOfArray(new int[] {}));
	}
	}


