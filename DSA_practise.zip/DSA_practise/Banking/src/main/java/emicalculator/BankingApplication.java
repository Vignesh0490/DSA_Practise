package emicalculator;
//p - principal
//r - rate
//t - tenure

public class BankingApplication {
	public double calculateEMI(double p, double r, double t) {
		//float monthlyInterest =  r/(12/100);
		//float numberOfPayment = t * 12;
		 //p = 10000;
		 //r = 10;
		 //t = 2;
		double emi = (p * r * (double)Math.pow(1 + r, t)) 
                / (double)(Math.pow(1 + r, t) - 1);
		System.out.println("emi:" + emi);
		return emi;	
	}
}



