package emicalculator;

public class ComplexInterest {
	public double calculateComplex(double p, double r, double t) {
		double compound = p * (Math.pow((1 + r / 100), t)) - p;
		System.out.println("compound" + compound);
		return compound;
	}

}
