package ArraysTraining;

public class findMaxOnes {
	static int findMaxConsecutiveOnes(int[] nums) {
		int count = 0;
		int maxi = 0; // to maintain the maximum number of 1s
		for (int i = 0; i < nums.length; i++) {
			if (nums[i] == 1) {
				count++;
			} else {
				count = 0;
			}
			//dataType max(dataType num1, dataType num2)
			//Parameters : The function accepts two parameters num1 and num2 
			//among which the maximum is returned
			maxi = Math.max(maxi, count); 
		}
		return maxi;

	}

	public static void main(String[] args) {
		int nums[] = {1,1,0,0,1,1,1,1};
		int finalCount = findMaxConsecutiveOnes(nums);
		System.out.println("The number of consecutive ones is :" + finalCount);

	}

}
