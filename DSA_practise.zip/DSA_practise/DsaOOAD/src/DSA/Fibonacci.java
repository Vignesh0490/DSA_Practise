package DSA;

public class Fibonacci {

	public static void main(String[] args) {
		int a = 0;
		int b = 1;
		int sum = 0;
		int i = 1;
		System.out.print("Fibonacci series - " );
		while(i<13) {
			sum = a+b;
			System.out.print(a + " ");
			a = b;
			b = sum;
			i++;
		
		}

	}

}
