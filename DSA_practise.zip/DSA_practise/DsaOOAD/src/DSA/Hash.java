package DSA;

import java.util.HashMap;
import java.util.Hashtable;

public class Hash {

	public static void main(String[] args) {
		Hashtable <String, Integer> profile = new Hashtable<>();
		profile.put("Vignesh", 101);
		profile.put("Shahid", 102);
		profile.put("pradeep", 103);
		System.out.println("New profile " + profile.get("Vignesh"));
		System.out.println("Updated profile: " + profile.remove("pradeep"));
		System.out.println("Boolean: " + profile.containsKey("pradeep"));
		

	}

}
