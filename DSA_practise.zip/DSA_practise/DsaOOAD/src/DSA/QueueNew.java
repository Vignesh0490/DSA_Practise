package DSA;

import java.util.LinkedList;
import java.util.Queue;

public class QueueNew {

	public static void main(String[] args) {
		Queue<Integer> qu = new LinkedList<>();
		qu.offer(200);
		qu.offer(300);
		qu.offer(400);
		qu.offer(500);
		System.out.println(qu);
		// To remove the element
		int dequeue = qu.poll();
		System.out.println("Removing the element :" + dequeue);
		// to peek the element
		int peeking = qu.peek();
		System.out.println("Peeking the element :" + peeking);
		// to check if it is empty
		boolean checkEmpty = qu.isEmpty();
		System.out.println("Boolean Empty :" + checkEmpty);
	}

}
