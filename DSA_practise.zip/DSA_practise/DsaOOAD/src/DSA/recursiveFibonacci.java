package DSA;
//Implement a Java recursive function to calculate the nth Fibonacci number

public class recursiveFibonacci {
	public static int calculateFibonacci(int N) {
		if (N == 0) {
			return 0;
		}
		if (N == 1) {
			return 1;
		}
		return calculateFibonacci(N-1) + calculateFibonacci(N-2);
	}

	public static void main(String[] args) {
		int N = 10;
		int result  = calculateFibonacci(N);
		System.out.println("The Nth Fibonacci number is " + result);

	}

}
