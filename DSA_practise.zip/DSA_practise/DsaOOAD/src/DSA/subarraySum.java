package DSA;

public class subarraySum {
	public static int maxSubArray(int[] nums) {

		int maxSum = Integer.MIN_VALUE; // Starting from the 0th index -- smallest possible value (maxSum = 6)
		for (int i = 0; i < nums.length; i++) {
			int currentSum = 0;
			for (int j = i; j < nums.length; j++) { // 2nd pointer
				// Calculate the sum of the sub-array from index i to j
				currentSum = currentSum + nums[j];
				maxSum = Math.max(maxSum, currentSum);
			}
		}
		return maxSum;
	}

	public static void main(String[] args) {
		int num[]= {-2,1,-3,4,-1,2,1,-5,4};
		int maxSum = maxSubArray(num);
		System.out.println("Sub-array: " + maxSum);

	}

}
