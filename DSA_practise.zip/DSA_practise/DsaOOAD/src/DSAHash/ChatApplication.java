package DSAHash;

import java.util.Hashtable;

public class ChatApplication {
	private Hashtable<String, UserProfile> userProfiles = new Hashtable<>();
	private Hashtable<String, ChatSession> activeChat = new Hashtable<>();

	// Method to add a user profile
	public void addUserProfile(String username, String fullName) {
		UserProfile profile = new UserProfile(username, fullName);
		userProfiles.put(username, profile);
		//userProfiles.put(fullName, profile);
	}

	// Method to create chat session
	public void startChatSession(String user1, String user2) {
		ChatSession chatSession = new ChatSession(user1, user2);
		activeChat.put(user1+ "-"+ user2, chatSession);
		//activeChat.put(user2, chatSession);
	}

	public UserProfile getUserProfile(String username) {
		return userProfiles.get(username);
	}

	public ChatSession getChatSession(String user1, String user2) {
		return activeChat.get(user1 + "-" + user2);

	}

}
