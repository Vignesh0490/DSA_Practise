package DSAHash;

public class Main {

	public static void main(String[] args) {
		ChatApplication chatApp = new ChatApplication();
		chatApp.addUserProfile("user1", "Vignesh");
		chatApp.addUserProfile("user2","Shahid");
		
		chatApp.startChatSession("user1", "user2");
		UserProfile profile1 = chatApp.getUserProfile("user1");
		UserProfile profile2 = chatApp.getUserProfile("user2");
		
		System.out.println("user1" + " " + profile1.getFullName());
		System.out.println("user2" + " " + profile2.getFullName());
		
		ChatSession chatSession = chatApp.getChatSession("user1", "user2");
		if(chatSession != null) {
			System.out.println("Active chat Session between" + " " + chatSession.getUser1() + " & " +chatSession.getUser2());
		}else {
			System.out.println("No active chat Session");
		}
		

	}

}
