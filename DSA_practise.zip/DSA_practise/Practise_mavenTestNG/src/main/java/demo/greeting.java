package demo;

public class greeting {
	public String begin(String B) {
		B = "Open Website";
		return B;
	}
	public String login(String L) {
		L = "Login";
		return L;
	}
	public String password(String H) {
		H = "Home page";
		return H;
	}
	public String contact(String C) {
		C = "Contact us";
		return C;
	}
	public String find(String F) {
		F = "Find contact details";
		return F;
	}
	public String phone(String P) {
		P = "Retrive phone number";
		return P;
	}
	

}
