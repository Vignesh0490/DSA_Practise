package Mocking;

public interface UserRepository {
	User findbyID(int userId);

}
