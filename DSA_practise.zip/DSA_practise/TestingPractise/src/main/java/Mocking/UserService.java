package Mocking;

public class UserService {
	private final UserRepository userRepository;

	//constructor
	public UserService(UserRepository userRepository) {
		this.userRepository = userRepository;		
	}
	
	public User getUserByID(int userId) {
		return userRepository.findbyID(userId);
	}

}
