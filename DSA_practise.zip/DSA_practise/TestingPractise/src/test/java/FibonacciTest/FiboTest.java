package FibonacciTest;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import Fibonacci.Fibo;

public class FiboTest {
	Fibo fibo = new Fibo();

	@ParameterizedTest
	@ValueSource(ints = { 0, 1, 2, 3, 4, 5, 10, 15, 20 })
	public void calculatefibo(int n) {
		
		

	}
}
