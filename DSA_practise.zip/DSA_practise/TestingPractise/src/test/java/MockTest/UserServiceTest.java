package MockTest;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.testng.Assert.assertEquals;

import org.junit.Test;

import Mocking.User;
import Mocking.UserRepository;
import Mocking.UserService;

public class UserServiceTest {

	@Test
	public void userTest() {
		UserRepository userRepository = mock(UserRepository.class);
		UserService userService = new UserService(userRepository);
		
		int userId = 1;
		User user = new User();
		user.setId(userId);
		user.setUsername("Vignesh");
		
		when(userRepository.findbyID(userId)).thenReturn(user);
		
		User result = userService.getUserByID(userId);
		
		verify(userRepository).findbyID(userId);
		
		assertEquals(userId, result.getId());
		assertEquals("Vignesh",result.getUsername());
		

	}
}
