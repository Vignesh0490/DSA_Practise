package UserRegistrationTest;

import static org.junit.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import Registration.UserRegistration;

public class UserRegistrationTest {

	 UserRegistration user;

	@Before
	public void setUp() {
		user = new UserRegistration();
	}
	@Test //username
	public void testUsername() {
		assertTrue(user.validateUsername("Vignesh04"));		
	}
	@Test
	public void testFailUsername() {
		assertFalse(user.validateUsername("abc"));
	}
	@Test //email
	public void testEmail() {
		assertTrue(user.validateEmail("vignesh@gmail.com"));
	}
	@Test
	public void testFailEmail() {
		assertFalse(user.validateEmail("vignesh123"));
	}
	@Test //Password
	public void testPassword() {
		assertTrue(user.validatePassword("Global@123"));
	}
	//@Test
	public void testFailPassword() {
		assertFalse(user.validatePassword("Global123"));
	} //Age
	public void testAge() {
		assertTrue(user.validateAge(30));
	}
	public void testFailAge() {
		assertFalse(user.validateAge(12));
	}

}
